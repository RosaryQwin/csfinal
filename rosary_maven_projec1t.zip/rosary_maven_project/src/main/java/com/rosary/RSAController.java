package com.rosary;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.math.BigInteger;

@Controller
public class RSAController {

    @PostMapping("/sign")
    @ResponseBody
    public String signMessage(@RequestParam String item_units,
                              @RequestParam String item_id,
                              @RequestParam String item_price,
                              @RequestParam String inventory_id) throws Exception {
    
        BigInteger[] keys = KeyLoader.loadKeys(inventory_id, "src/main/resources/keys.json");
        RSA rsa = new RSA(keys[0], keys[1], keys[2]);
        String message = item_units + item_id + item_price + inventory_id;
        BigInteger signature = rsa.sign(message);
        boolean verified = rsa.verify(message, signature);
        boolean consensus = Consensus.verifyWithMajority(inventory_id, message, signature);
        if (consensus == true){
            RSA.save_record(inventory_id,item_id,item_units,item_price);
        }   
        
        return "<h2>Signed Result</h2>" +
               "<h3>Location " + inventory_id + "</h3>" +
               "<p><strong>Message:</strong> " + message + "</p>" +
               "<p><strong>Signature:</strong> " + signature + "</p>" +
               "<p><strong>Verification:</strong> " + (verified ? " Valid" : "Invalid") + "</p>" +
               "<p><strong>Consensus:</strong> " + (consensus ? "Block Accepted (2/3+ nodes verified)" : "Block Rejected (consensus failed)") + "</p>" + 
               "<hr>" + 
               getFormHtml();
    }

    private String getFormHtml() {
        return "<h2>Sign a Message</h2>" +
               "<form action=\"/sign\" method=\"post\">" +
               "<label>Item QTY:</label>" +
               "<input type=\"text\" name=\"item_units\" required />" +
               "<label>Item ID:</label>" +
               "<input type=\"text\" name=\"item_id\" required />" +
               "<label>Item Price:</label>" +
               "<input type=\"text\" name=\"item_price\" required />" +
               "<label>Location</label>" +
               "<select name=\"inventory_id\" required>" +
               "<option value=\"A\">Inventory A</option>" +
               "<option value=\"B\">Inventory B</option>" +
               "<option value=\"C\">Inventory C</option>" +
               "<option value=\"D\">Inventory D</option>" +
               "</select>" +
               "<br><br>" +
               "<button type=\"submit\">Sign</button>" +
               "</form>";
    }
    
}
