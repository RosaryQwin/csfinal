package com.rosary;

import java.math.BigInteger;

public class Main {
    public void main(String[] args) throws Exception {
        String inventoryId = "A";
        BigInteger[] keys = KeyLoader.loadKeys(inventoryId, "src/main/resources/keys.json");

        RSA rsa = new RSA(keys[0], keys[1], keys[2]);

        String message = "Inventory " + inventoryId + ": ID=001, Quantity=32, Price=12";
        BigInteger signature = rsa.sign(message);
        boolean verified = rsa.verify(message, signature);

        System.out.println("Signature: " + signature);
        System.out.println("Verification: " + verified);
    }
}
