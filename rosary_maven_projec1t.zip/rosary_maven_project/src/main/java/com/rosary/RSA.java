package com.rosary;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.io.FileWriter;
import java.io.File;
import java.io.IOException;
public class RSA {
    private BigInteger n, e, d;

    public RSA(BigInteger p, BigInteger q, BigInteger e) {
        this.e = e;
        this.n = p.multiply(q);
        BigInteger phi = (p.subtract(BigInteger.ONE)).multiply(q.subtract(BigInteger.ONE));
        this.d = e.modInverse(phi);
    }
    // Inventory sign the record, Task 1 part2
    public BigInteger sign(String message) throws Exception {
        BigInteger hash = hashMessage(message);
        return hash.modPow(d, n);
    }
    // taking public key to get decrypted hash task 1 part3
    public boolean verify(String message, BigInteger signature) throws Exception {
        BigInteger originalHash = hashMessage(message);
        BigInteger decryptedHash = signature.modPow(e, n);
        return originalHash.equals(decryptedHash);
    }

    private BigInteger hashMessage(String message) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hash = md.digest(message.getBytes("UTF-8"));
        return new BigInteger(1, hash);
    }

    public static  void save_record(String inventoryId, String itemid, String itemqty, String itemprice){
        try{
            String filename = "src/main/resources/data/" + inventoryId + "_ledger.txt";
            File file = new File(filename);
            file.getParentFile().mkdirs();

            FileWriter writer = new FileWriter(file, true);
            writer.write(itemid + " " + itemqty + " " + itemprice + " " + inventoryId + "\n");
            writer.close();
        }
        catch (IOException e){
            e.printStackTrace();
        }

    }
}
